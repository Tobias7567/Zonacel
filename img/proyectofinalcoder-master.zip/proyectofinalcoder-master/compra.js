let carritoLocalStorage = JSON.parse(localStorage.getItem('carrito'));
let conten = document.getElementById('ubicaciondetd')
let vaciarboton = document.getElementById('vc')
let divcompras = document.getElementById('divcompras')
let articulosCarrito = [];
/*colecta de  datos */
let buttondedatos = document.getElementById('botondedatos')
let inputNombre = document.getElementById('nombre')
let inputCelular = document.getElementById('celular')
let contenedordedato = document.getElementById('contenedordedato')
let contenedordedato1 = document.getElementById('contenedordedato1')
let contenedordebuttondatos = document.getElementById('contenedordebuttondatos')


resgistrodeclick()
creadordetotal()
creadosdetexto()
function resgistrodeclick() {
 
  vaciarboton.addEventListener('click' ,  () =>   {
carritoLocalStorage = []; // vaciamos el array 
limpiarcarrito() // limpiamos el html
    } ) 
  buttondedatos.addEventListener('click', guardardatos1) 
 
    

    }

function guardardatos1() {
let itemtext1 = inputNombre.value;
let itemtext2= inputCelular.value;

creadordedatos(itemtext1 , itemtext2)
}
function creadordedatos (itemtext1 , itemtext2) {
let datos = document.createElement("h3")
let datos1 = document.createElement("h3")
datos.innerHTML= `<h3 class= "h3dejs">Nombre :${itemtext1} </h3>`
datos1.innerHTML= `<h3 class= "h3dejs">Numero :${itemtext2} </h3>`
contenedordedato.appendChild(datos);
contenedordedato1.appendChild(datos1);
}



  

  // carrito vacio
function limpiarcarrito()  {
    while(conten.firstChild) {
      conten.removeChild(conten.firstChild);
        }
      }
function creadosdetexto() {
 
        carritoLocalStorage.forEach( combo =>  {
            let texto = document.createElement('h3')
      texto.innerHTML= 
      `<div id= "combojs">
    <td > ${combo.titulo}</td>
<td > $${combo.precio}</td>
<td > ${combo.cantidad}</td>
 </div>`
      
divcompras.appendChild(texto);
    }
        )
    }

  
    function creadordetotal() {
      carritoLocalStorage.forEach( combo =>  {
       let precio1 = [parseInt((combo.precio*combo.cantidad)) ]
      
console.log(precio1);
  }
      )
  }

    $(document).ready(function(){
      $("#ocultarcompra").on( "click", function() {
        $('#divcompras').hide();
      
       });
      $("#mostrarcompra").on( "click", function() {
        $('#divcompras').show();
      });
    });
/*+
const urlget = "./datos.json"
$("#contenedordebuttondatos ").prepend('<button id="btn1">mostrardatos</button>')
$("#btn1").click(() =>  {  
  $.get(urlget , function (respuesta , estado) {
    if(estado ==="success") {
      
      let dato = document.createElement('h3')
      dato.innerHTML= `<td> ${respuesta}</td>`
      contenedordebuttondatos .appendChild(dato);
    }
  })
})
*/