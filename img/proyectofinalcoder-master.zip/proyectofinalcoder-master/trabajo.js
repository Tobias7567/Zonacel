
let carrito = document.querySelector( '#carrito') 
 
let conten = document.getElementById('ubicaciondetd')
let vaciarboton = document.getElementById('vc')
let listacombos = document.getElementById('lista');
let articulosCarrito = [];

resgistrodeclick()

function resgistrodeclick() {
  listacombos.addEventListener('click', agregarcombo);
  vaciarboton.addEventListener('click' ,  () =>   {
  articulosCarrito = []; // vaciamos el array 
  limpiarcarrito() // limpiamos el html 
} ) 
conten.addEventListener('click', eliminarCombo);
 }

// buscador de  datos de combo 
  function agregarcombo (e){
    if(e.target.classList.contains('buttoncombos')) {
      let datoscombo = e.target.parentElement ;
          leerDatosCombo(datoscombo);

        }}
  //lector de datos de combo 
  function leerDatosCombo(datoscombo) {
    const infocombo = {
      titulo: datoscombo.querySelector('#numerodecombo').textContent,
      precio: datoscombo.querySelector('#preciodecombo').textContent, 
      cantidad : 1
      }     

// sumar cantidad 
      const existe = articulosCarrito.some(combo => combo.titulo === infocombo.titulo);   
      {
        if(existe)  {
                     const combo = articulosCarrito.map(combo => { if(combo.titulo === infocombo.titulo){
                      combo.cantidad++;
                   return combo
                             } })}
                   else{
                      articulosCarrito = [...articulosCarrito , infocombo]
      }}
  
       localStorage.setItem('carrito', JSON.stringify(articulosCarrito));
       
        carritoenhtml() 
        }
      
    
      function eliminarCombo(e){
    
          if(e.target.classList.contains('borrar-curso') ) {
               const titulo = e.target.getAttribute('titulo')
               
               // Eliminar del arreglo del carrito
               articulosCarrito = articulosCarrito.filter(combo => combo.titulo !== titulo);
     
               carritoenhtml();
          }
       }  
    //agregando datos al carrito 
  function carritoenhtml()  { 
    limpiarcarrito();
         articulosCarrito.forEach( combo =>  {
         let row = document.createElement('tr')
      row.innerHTML= 
     `<td> ${combo.titulo}  </td>
      <td> $${combo.precio}  </td>
      <td> ${combo.cantidad}  </td>
      <td><button class="borrar-curso" titulo="${combo.titulo}">X</button></td>`
      conten.appendChild(row);
    })}
  

  // carrito vacio
  function limpiarcarrito()  {
    while(conten.firstChild) {
      conten.removeChild(conten.firstChild);
     } }


 
  




  
 