let carritoLocalStorage = JSON.parse(localStorage.getItem('carrito'));
let conten = document.getElementById('ubicaciondetd')
let vaciarboton = document.getElementById('vc')
resgistrodeclick()
carritoenhtml()

function resgistrodeclick() {
 
    vaciarboton.addEventListener('click' ,  () =>   {
  carritoLocalStorage = []; // vaciamos el array 
  
  
  limpiarcarrito() // limpiamos el html
      } )  }
  
  
  
function carritoenhtml()  { 
      carritoLocalStorage.forEach( combo =>  {
        let row = document.createElement('tr')
  row.innerHTML= 
  `<td> ${combo.titulo}</td>
  <td> ${combo.precio}</td>
  <td> ${combo.cantidad}</td>`
  
  conten.appendChild(row);
      })
    } 
  
    // carrito vacio
function limpiarcarrito()  {
      while(conten.firstChild) {
        conten.removeChild(conten.firstChild);
  
          }

          }